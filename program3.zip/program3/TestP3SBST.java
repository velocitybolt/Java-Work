package program3;

import stdlib.*;

public class TestP3SBST {

	public static void main(String[] args) {
		P3SimplerBST<String, Integer> wordCounts = new P3SimplerBST<>();
		StdIn.fromFile("data/tale.txt");
		while(!StdIn.isEmpty()) {
			String word = StdIn.readString().toLowerCase();
			if (!wordCounts.contains(word)) {
				wordCounts.put(word, 1);
			} else {
				wordCounts.put(word, wordCounts.get(word) + 1);
			}
		}
		StdOut.println("The size of the tree is " + wordCounts.size() + " nodes");
		StdOut.println("The height of the tree (BST 1) is " + wordCounts.height());
		
		
		P3SimplerBST<String, Integer> heightCounts = new P3SimplerBST<>();
		StdIn.fromFile("data/tale.txt");
		while(!StdIn.isEmpty()) {
			String word2 = StdIn.readString().toLowerCase();
			if (!heightCounts.contains(word2)) {
				heightCounts.put(word2, 1);
			} else {
				heightCounts.put(word2, heightCounts.get(word2) + 1);
			}
		}
		StdOut.println("The height of the tree (BST 2) is " + heightCounts.height());
		

	}

}
