package program2;
// Author: Murtaza Meerza
import algs31.*;
import algs32.*;
import stdlib.*;

public class TimeSymbolTables {

    // ALGS 32 BST
	public static void main(String[] args) {	
	Stopwatch t2 = new Stopwatch();
	BST<String, Integer> wordCounts2 = new BST<String, Integer>();
	StdIn.fromFile("data/tale.txt");
	while(!StdIn.isEmpty()) {
		String word2 = StdIn.readString().toLowerCase();
		if (!wordCounts2.contains(word2)) {
			wordCounts2.put(word2, 1);
		} else {
			wordCounts2.put(word2, wordCounts2.get(word2) + 1);
		}
	}
	double time2 = t2.elapsedTime();
	StdOut.println("ALGS32 BST Time : " + time2);
 
	
	// ALGS 31 SST
	Stopwatch t1 = new Stopwatch();
	SequentialSearchST<String, Integer> wordCounts = new SequentialSearchST<String, Integer>();
	StdIn.fromFile("data/tale.txt");
	while(!StdIn.isEmpty()) {
		String word = StdIn.readString();
		if (!wordCounts.contains(word)) {
			wordCounts.put(word, 1);
		} else {
			wordCounts.put(word, wordCounts.get(word) + 1);
		}
	}
	double time1 = t1.elapsedTime();
	StdOut.println("ALGS31 SST Time : " + time1);
		
		
	}
}