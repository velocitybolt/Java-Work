package program2;
// Author: Murtaza Meerza
import stdlib.*;

public class FileMaxMin {

	public static void main(String[] args) {
		StdIn.fromFile("data/100ints.txt");
		int number = 0;
		int min = Integer.MAX_VALUE;
		int max = Integer.MIN_VALUE;
		
		while(!StdIn.isEmpty()) {
			number = StdIn.readInt();
			if (number > max) {
				max = number;
			}
			if (number < min) {
				min = number;
			}
		}
		StdOut.println("The max is : "+ max);
		StdOut.println("The min is: "+ min);
	
		 
		
		
		
		

	}
}
