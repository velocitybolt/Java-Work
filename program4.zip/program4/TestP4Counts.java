package program4;
// Author : Murtaza Meerza
import stdlib.*;
import java.util.*;

public class TestP4Counts {

	public static void main(String[] args) {
		
		// BST NON - SORTED
		P4SimplerBST<Integer, Boolean> numCounts = new P4SimplerBST<>();
		StdIn.fromFile("data/8kints.txt");
		int[] nums = StdIn.readAllInts();
		for (int n : nums){
			numCounts.put(n, true);
		}
		StdOut.println("The number of Comparisons of P4SimplerBST is " + numCounts.comparisonCount());

		// AVL NON - SORTED
		P4SimplerAVLTree<Integer, Boolean> numCounts2 = new P4SimplerAVLTree<>();
		StdIn.fromFile("data/8kints.txt");
		int[] nums2 = StdIn.readAllInts();
		for (int n2 : nums2){
			numCounts2.put(n2, true);
		}
		StdOut.println("The number of Comparisons of P4SimplerAVLTree is " + numCounts2.comparisonCount());
		
		// BST SORTED
		P4SimplerBST<Integer, Boolean> sortedCounts = new P4SimplerBST<>();
		StdIn.fromFile("data/8kints.txt");
		int[] sorted = StdIn.readAllInts();
		Arrays.sort(sorted);
		for (int n3 : sorted){
			sortedCounts.put(n3, true);
		}
		StdOut.println("The number of Comparisons of Sorted P4SimplerBST is " + sortedCounts.comparisonCount());
		
		// AVL SORTED
		P4SimplerAVLTree<Integer, Boolean> sortedCounts2 = new P4SimplerAVLTree<>();
		StdIn.fromFile("data/8kints.txt");
		int[] sorted2 = StdIn.readAllInts();
		Arrays.sort(sorted2);
		for (int n4 : sorted2){
			sortedCounts2.put(n4, true);
		}
		StdOut.println("The number of Comparisons of Sorted P4SimplerAVLTree is " + sortedCounts2.comparisonCount());
		
		
		
		
		
		
		
		
		
		
		
	}

}
