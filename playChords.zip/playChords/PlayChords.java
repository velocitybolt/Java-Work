
// Author: Murtaza Meerza

package playChords;

import stdlib.*;

public class PlayChords {
	
	public static void playChord(double duration, double[] frequencies) {
		final int sliceCount = (int) (StdAudio.SAMPLE_RATE * duration);
		final double[] slices = new double[sliceCount+1];
		for (int i = 0; i <= sliceCount; i++) {
			double chord = 0.0;
			for (double frequency: frequencies) {
				chord += Math.sin(2 * Math.PI * i * frequency / StdAudio.SAMPLE_RATE);
			}
			slices[i] = chord/frequencies.length;
		}
		StdAudio.play(slices);
	}
		public static void main(String[] args) {
			StdIn.fromFile("data/chords.txt");
		    while(!StdIn.isEmpty()){
		    	double[] chordArray = new double[2];
		    	double duration = StdIn.readDouble();
		    	for (int i = 0; i<2; i++) {
		    		chordArray[i]=StdIn.readDouble();		
		    	}
		    	playChord(duration,chordArray);
		    	
		    
		    		}
		    		
		    			}
		   
		    	
		    		

			 {
			}
			}
			
			
					
					
				
				
		
			
				
			
			
			
			
	


	
		
	

	


