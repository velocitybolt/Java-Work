package program1;

// Author: Murtaza Meerza

import algs31.*;
import stdlib.*;

public class PlaySimpleSong {

	public static void main(String[] args) {
		StdIn.fromFile("data/notes_frequencies.txt");
		BinarySearchST<String, Double> song = new BinarySearchST<>();
		String line = StdIn.readLine();
		String[] pairs = line.split("\\s");
		String note = pairs[0];
		Double freq = Double.parseDouble(pairs[1]);
		song.put(note, freq);
		
		StdIn.fromFile("data/lotr.txt");
		BinarySearchST<String, Double> songtwo = new BinarySearchST<>();
		while(!StdIn.isEmpty()){
			String linetwo = StdIn.readLine();
			String[] pairstwo = linetwo.split("\\s");
			String notetwo = pairstwo[0];
			Double dura = Double.parseDouble(pairstwo[1]);
			songtwo.put(notetwo,dura);
		
		playTone(freq,dura);
		}
	}
	public static void playTone(double frequency, double duration) {
		final int sliceCount = (int) (StdAudio.SAMPLE_RATE * duration);
		final double[] slices = new double[sliceCount+1];
		for (int i = 0; i <= sliceCount; i++) {
			slices[i] = Math.sin(2 * Math.PI * i * frequency / StdAudio.SAMPLE_RATE);
		}
		StdAudio.play(slices);
	}

}


