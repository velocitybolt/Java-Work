package program1;

// Author: Murtaza Meerza

import stdlib.*;
import algs31.BinarySearchST;

public class ComputeGPA {

	public static void main(String[] args) {
		BinarySearchST<String, Double> convert = new BinarySearchST<String, Double>();
		convert.put("A+", 4.33);
		convert.put("A", 4.00);
		convert.put("A-", 3.67);
		convert.put("B+", 3.33);
		convert.put("B", 3.00);
		convert.put("B-", 2.67);
		convert.put("C+", 2.33);
		convert.put("C", 2.00);
		convert.put("C-", 1.67);
		convert.put("D", 1.00);
		convert.put("F", 0.00);
		
		
		//for (String s : convert.keys())
			//StdOut.println(s + " " + convert.get(s));
		
		StdIn.fromFile("data/a1grades.txt");
		double sum = 0.0;
		int total = 0;
		while(!StdIn.isEmpty()) {
			String reportcard = StdIn.readString();
            double grade = convert.get(reportcard);
            sum += grade;
            total++;
            //StdOut.print(reportcard);
		}
		double gpa = sum / total;
        StdOut.println("GPA is: "+gpa);
		
				 
 }

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

